import { Component, ChangeDetectorRef, OnInit, ViewChild } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatCardModule } from '@angular/material/card';
import { MatTabsModule } from '@angular/material/tabs';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';

import * as cornerstone from 'cornerstone-core';
import * as cornerstoneTools from 'cornerstone-tools';
import * as cornerstoneWADOImageLoader from 'cornerstone-wado-image-loader';
import * as dicomParser from 'dicom-parser';
import { DicomProcessorService } from '../../../../core/services/dicom/dicom-processor.service';

import { DicomUploaderComponent } from '../dicom-uploader/dicom-uploader.component';
import { DicomViewerComponent } from '../dicom-viewer/dicom-viewer.component';
import { DicomToolsComponent } from '../dicom-tools/dicom-tools.component';
import { DicomMetadataComponent } from '../dicom-metadata/dicom-metadata.component';

interface WindowWithHammer extends Window {
  Hammer?: any;
}

@Component({
  selector: 'app-modulo-visualizador',
  standalone: true,
  imports: [
    CommonModule,
    MatCardModule,
    MatTabsModule,
    MatIconModule,
    MatButtonModule,
    DicomUploaderComponent,
    DicomViewerComponent,
    DicomToolsComponent,
    DicomMetadataComponent
  ],
  templateUrl: './modulo-visualizador.component.html',
  styleUrls: ['./modulo-visualizador.component.css']
})
export class ModuloVisualizadorComponent implements OnInit {
  @ViewChild(DicomViewerComponent) dicomViewer!: DicomViewerComponent;

  imageLoaded = false;
  metadata: any[] = [];
  fileError: string | null = null;
  currentImageId: string | null = null;

  // Nuevo estado como arreglo
  activeToolNames: string[] = [];

  // Actualizar el objeto activeTools para incluir la herramienta de medición
  activeTools = {
    zoom: false,
    pan: false,
    windowLevel: false,
    measure: false  // Nueva herramienta de medición
  };

  constructor(
    private cdr: ChangeDetectorRef,
    private dicomProcessor: DicomProcessorService
  ) {}

  ngOnInit(): void {
    if (typeof window !== 'undefined') {
      try {
        cornerstoneTools.external.cornerstone = cornerstone;

        const windowWithHammer = window as WindowWithHammer;
        if (windowWithHammer.Hammer) {
          cornerstoneTools.external.Hammer = windowWithHammer.Hammer;
        }

        cornerstoneTools.init({
          mouseEnabled: true,
          touchEnabled: false,
          globalToolSyncEnabled: false,
          showSVGCursors: true
        });

        cornerstoneWADOImageLoader.external.cornerstone = cornerstone;
        cornerstoneWADOImageLoader.external.dicomParser = dicomParser;
        cornerstoneWADOImageLoader.configure({ beforeSend: () => {} });

        if (cornerstoneWADOImageLoader.webWorkerManager) {
          cornerstoneWADOImageLoader.webWorkerManager.initialize({
            maxWebWorkers: navigator.hardwareConcurrency || 1,
            startWebWorkersOnDemand: true,
            taskConfiguration: {
              decodeTask: { usePDFJS: false }
            }
          });
        }

        console.log('✅ Cornerstone y herramientas inicializadas');
      } catch (error) {
        console.error('❌ Error en inicialización Cornerstone:', error);
      }
    }
  }

  processFile(file: File): void {
    this.fileError = null;
    const reader = new FileReader();

    reader.onload = () => {
      try {
        const arrayBuffer = reader.result as ArrayBuffer;
        const result = this.dicomProcessor.parseDicomFile(arrayBuffer);

        if (!result.isValid) {
          this.fileError = result.error;
          return;
        }

        this.metadata = this.dicomProcessor.extractAllDicomTags(result.dataSet);
        this.metadata.sort((a, b) => a.tag.localeCompare(b.tag));

        const byteArray = new Uint8Array(arrayBuffer);
        const blob = new Blob([byteArray]);
        this.currentImageId = cornerstoneWADOImageLoader.wadouri.fileManager.add(blob);

        this.imageLoaded = true;
        this.cdr.detectChanges();
      } catch (error: any) {
        console.error('❌ Error al procesar archivo DICOM:', error);
        this.fileError = 'Error al procesar archivo: ' + (error.message || 'Error desconocido');
        this.cdr.detectChanges();
      }
    };

    reader.onerror = (error: any) => {
      console.error('❌ Error al leer archivo:', error);
      this.fileError = 'Error al leer el archivo.';
      this.cdr.detectChanges();
    };

    reader.readAsArrayBuffer(file);
  }

  // Nuevo enfoque para herramientas independientes
  onZoomToggled(active: boolean): void {
    this.activeTools.zoom = active;
    this.syncActiveTools();
  }

  onPanToggled(active: boolean): void {
    this.activeTools.pan = active;
    this.syncActiveTools();
  }

  onWindowLevelToggled(active: boolean): void {
    this.activeTools.windowLevel = active;
    this.syncActiveTools();
  }

  // Añadir un nuevo método para manejar el toggle de la herramienta de medición
  onMeasureToggled(active: boolean): void {
    this.activeTools.measure = active;
    this.syncActiveTools();
  }

  private syncActiveTools(): void {
    const tools: string[] = [];
    if (this.activeTools.zoom) tools.push('Zoom');
    if (this.activeTools.pan) tools.push('Pan');
    if (this.activeTools.windowLevel) tools.push('Wwwc');
    if (this.activeTools.measure) tools.push('Length'); // Añadir herramienta de medición

    this.activeToolNames = tools;

    if (this.dicomViewer) {
      this.dicomViewer.setToolActive(this.activeToolNames);
    }
  }

  resetZoom(): void {
    if (this.dicomViewer) {
      this.dicomViewer.resetViewport();
    }
  }
  onToolsChanged(tools: string[]): void {
    this.activeToolNames = tools;
    
    // Update the activeTools object to match the new tool state
    this.activeTools = {
      zoom: tools.includes('Zoom'),
      pan: tools.includes('Pan'),
      windowLevel: tools.includes('Wwwc'),
      measure: tools.includes('Length')
    };
    
    // Force change detection
    this.cdr.detectChanges();
  }
}
