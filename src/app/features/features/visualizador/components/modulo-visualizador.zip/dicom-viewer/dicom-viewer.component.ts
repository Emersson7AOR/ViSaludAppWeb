import { Component, Input, OnChanges, SimpleChanges, ElementRef, ViewChild, AfterViewInit, OnDestroy, EventEmitter, Output } from '@angular/core';
import { CommonModule } from '@angular/common';
import * as cornerstone from 'cornerstone-core';
import * as cornerstoneTools from 'cornerstone-tools';
import { CornerstoneService } from '../../../../core/services/cornerstone/cornerstone.service';
import Swal from 'sweetalert2'; // Import SweetAlert

@Component({
  selector: 'app-dicom-viewer',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './dicom-viewer.component.html',
  styleUrls: ['./dicom-viewer.component.css']
})
export class DicomViewerComponent implements OnChanges, AfterViewInit, OnDestroy {
  @ViewChild('dicomElement', { static: true }) dicomElement!: ElementRef;
  @Input() imageId: string | null = null;
  @Input() activeToolNames: string[] = [];
  @Output() toolsChanged = new EventEmitter<string[]>();


  private element: HTMLElement | null = null;
  private isToolActive = false;
  private eventHandlers: { [key: string]: EventListener } = {};

  constructor(private cs: CornerstoneService) {}

  ngAfterViewInit(): void {
    this.element = this.dicomElement.nativeElement;
    this.initializeElement();
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['imageId'] && this.imageId && this.element) {
      this.loadAndDisplayImage();
    }
    if (changes['activeToolNames'] && this.element) {
      this.updateToolState();
    }
  }

  ngOnDestroy(): void {
    this.removeSafetyEventHandlers();
    if (this.element) {
      try {
        cornerstone.disable(this.element);
      } catch (error) {
        console.warn('Error disabling Cornerstone element:', error);
      }
    }
  }

  private initializeElement(): void {
    if (!this.element) return;
    try {
      this.element.style.width = '100%';
      this.element.style.height = '512px';
      this.element.style.backgroundColor = '#000';
      this.addSafetyEventHandlers();
      this.cs.habilitarElemento(this.element);
      if (this.imageId) {
        this.loadAndDisplayImage();
      }
    } catch (error) {
      console.error('Error initializing element:', error);
    }
  }

  private addSafetyEventHandlers(): void {
    if (!this.element) return;
    const safetyHandler: EventListener = (event: Event) => {
      if (!this.isToolActive) {
        event.stopPropagation();
        event.preventDefault();
      }
    };
    this.eventHandlers['mousemove'] = safetyHandler;
    this.eventHandlers['mousedown'] = safetyHandler;
    this.eventHandlers['mouseup'] = safetyHandler;
    this.element.addEventListener('mousemove', this.eventHandlers['mousemove'], true);
    this.element.addEventListener('mousedown', this.eventHandlers['mousedown'], true);
    this.element.addEventListener('mouseup', this.eventHandlers['mouseup'], true);
  }

  private removeSafetyEventHandlers(): void {
    if (!this.element) return;
    Object.keys(this.eventHandlers).forEach(eventType => {
      this.element?.removeEventListener(eventType, this.eventHandlers[eventType], true);
    });
    this.eventHandlers = {};
  }

  private loadAndDisplayImage(): void {
    if (!this.element || !this.imageId) return;
    this.cs.cargarYMostrarImagen(this.element, this.imageId).then(() => {
      try {
        if (!cornerstone.getEnabledElement(this.element)) {
          cornerstone.enable(this.element!);
        }
        this.cs.inicializarHerramientas(this.element!);
        cornerstone.events.addEventListener('cornerstoneimagerendered', () => this.updateToolState(), this.element);
      } catch (error) {
        console.error('Error initializing tools:', error);
      }
    }).catch(error => {
      console.error('Error loading or displaying image:', error);
    });
  }

  private updateToolState(): void {
    if (!this.element) return;
    try {
      console.log('Actualizando estado de herramientas:', this.activeToolNames);
      
      // Eliminar todos los manejadores de eventos existentes
      this.removeAllCustomHandlers();
      
      // Restablecer el estado activo
      this.isToolActive = false;
      
      // Asegurar que el elemento cornerstone está habilitado
      if (!cornerstone.getEnabledElement(this.element)) {
        cornerstone.enable(this.element);
      }
      
      // Desactivar todas las herramientas primero
      this.disableAllCornerstoneTools();
      
      // Verificar nuevamente si hay herramientas incompatibles (por seguridad)
      const hasPan = this.activeToolNames.includes('Pan');
      const hasWwwc = this.activeToolNames.includes('Wwwc');
      
      if (hasPan && hasWwwc) {
        // Si por alguna razón ambas están activas, desactivar Pan
        this.activeToolNames = this.activeToolNames.filter(tool => tool !== 'Pan');
        console.log('Conflicto detectado: Pan desactivado automáticamente');
        
        // Emitir el cambio de herramientas al componente padre
        this.toolsChanged.emit([...this.activeToolNames]);
        
        // Mostrar SweetAlert para informar al usuario
        this.showSweetAlert("No se pueden usar Mover y Contraste al mismo tiempo");
      }
      
      // Activar solo las herramientas seleccionadas
      if (this.activeToolNames && this.activeToolNames.length > 0) {
        // Crear un objeto para almacenar los manejadores por herramienta
        const toolHandlers: { [key: string]: { [eventType: string]: EventListener } } = {};
        
        // Activar cada herramienta y recopilar sus manejadores
        if (this.activeToolNames.includes('Wwwc')) {
          const wwwcHandlers = this.createWindowLevelHandlers();
          toolHandlers['Wwwc'] = wwwcHandlers;
          this.isToolActive = true;
          console.log('Window Level personalizado activado');
        }
        
        if (this.activeToolNames.includes('Zoom')) {
          const zoomHandlers = this.createZoomHandlers();
          toolHandlers['Zoom'] = zoomHandlers;
          this.isToolActive = true;
          console.log('Zoom activado');
        }
        
        if (this.activeToolNames.includes('Pan')) {
          const panHandlers = this.createPanHandlers();
          toolHandlers['Pan'] = panHandlers;
          this.isToolActive = true;
          console.log('Pan activado');
        }
        
        if (this.activeToolNames.includes('Length')) {
          const measurementHandlers = this.createMeasurementHandlers();
          toolHandlers['Length'] = measurementHandlers;
          this.isToolActive = true;
          console.log('Herramienta de medición activada');
        }
        
        // Registrar todos los manejadores recopilados
        this.registerCombinedHandlers(toolHandlers);
      }
      
      // Añadir manejadores de seguridad si no hay herramientas activas
      if (!this.isToolActive) {
        this.addSafetyEventHandlers();
        console.log('Manejadores de seguridad añadidos (sin herramientas activas)');
      }
      
      cornerstone.updateImage(this.element);
      
      // Asegurar que el cursor y las clases visuales se actualicen
      this.updateCursor();
    } catch (error) {
      console.error('Error updating tool state:', error);
    }
  }

  // Método para crear manejadores de Window Level sin registrarlos
  private createWindowLevelHandlers(): { [eventType: string]: EventListener } {
    const handlers: { [eventType: string]: EventListener } = {};
    
    // Variables para el seguimiento del estado del window level
    let isAdjusting = false;
    let lastPoint: { x: number, y: number } | null = null;

    handlers['mousedown'] = (event: Event) => {
      const e = event as MouseEvent;
      // Solo procesar si se presiona el botón izquierdo
      if (e.button !== 0) return;
      
      isAdjusting = true;
      lastPoint = { x: e.clientX, y: e.clientY };
      console.log('WindowLevel: mouseDown activado', lastPoint);
    };

    handlers['mousemove'] = (event: Event) => {
      const e = event as MouseEvent;
      
      // Si estamos ajustando, establecer el cursor y prevenir eventos predeterminados
      if (isAdjusting) {
        e.preventDefault();
        e.stopPropagation();
        
        if (!lastPoint) return;
        
        try {
          const enabledElement = cornerstone.getEnabledElement(this.element!);
          if (!enabledElement || !enabledElement.image) return;
          
          const viewport = cornerstone.getViewport(this.element!);
          
          // Calcular cambios en window width y window center
          const deltaX = e.clientX - lastPoint.x;
          const deltaY = e.clientY - lastPoint.y;
          
          // Ajustar sensibilidad basada en los valores actuales
          const wwBase = Math.max(viewport.voi.windowWidth, 1);
          const wcBase = Math.max(Math.abs(viewport.voi.windowCenter), 1);
          
          const wwSensitivity = wwBase * 0.01;
          const wcSensitivity = wcBase * 0.01;
          
          viewport.voi.windowWidth += (deltaX * wwSensitivity);
          viewport.voi.windowCenter -= (deltaY * wcSensitivity);
          
          if (viewport.voi.windowWidth < 1) {
            viewport.voi.windowWidth = 1;
          }
          
          viewport.voiLUT = undefined;
          
          cornerstone.setViewport(this.element!, viewport);
          cornerstone.updateImage(this.element!);
          
          lastPoint = { x: e.clientX, y: e.clientY };
        } catch (error) {
          console.warn('WindowLevel error:', error);
        }
      }
    };

    handlers['mouseup'] = (event: Event) => {
      const e = event as MouseEvent;
      if (!isAdjusting) return;
      
      isAdjusting = false;
      lastPoint = null;
      console.log('WindowLevel: mouseUp, ajuste finalizado');
    };

    handlers['mouseleave'] = (event: Event) => {
      const e = event as MouseEvent;
      if (!isAdjusting) return;
      
      isAdjusting = false;
      lastPoint = null;
      console.log('WindowLevel: mouseLeave, ajuste finalizado');
    };
    
    return handlers;
  }

  // Método para crear manejadores de Zoom sin registrarlos
  private createZoomHandlers(): { [eventType: string]: EventListener } {
    const handlers: { [eventType: string]: EventListener } = {};
    
    handlers['wheel'] = (event: Event) => {
      const e = event as WheelEvent;
      e.preventDefault();
      e.stopPropagation();
      
      try {
        const enabledElement = cornerstone.getEnabledElement(this.element!);
        if (!enabledElement || !enabledElement.image) return;
        
        const viewport = cornerstone.getViewport(this.element!);
        const zoomFactor = e.deltaY < 0 ? 1.1 : 0.9;
        viewport.scale *= zoomFactor;
        
        cornerstone.setViewport(this.element!, viewport);
        cornerstone.updateImage(this.element!);
      } catch (err) {
        console.warn('Zoom error:', err);
      }
    };
    
    return handlers;
  }

  // Método para crear manejadores de Pan sin registrarlos
  private createPanHandlers(): { [eventType: string]: EventListener } {
    const handlers: { [eventType: string]: EventListener } = {};
    
    // Variables para el seguimiento del estado del pan
    let isPanning = false;
    let lastPoint: { x: number, y: number } | null = null;

    handlers['mousedown'] = (event: Event) => {
      const e = event as MouseEvent;
      // Solo procesar si se presiona el botón izquierdo
      if (e.button !== 0) return;
      
      // Solo activar pan si no hay otra herramienta ajustando
      if (this.isAnyToolAdjusting()) return;
      
      isPanning = true;
      lastPoint = { x: e.clientX, y: e.clientY };
      console.log('Pan: mouseDown activado', lastPoint);
    };

    handlers['mousemove'] = (event: Event) => {
      const e = event as MouseEvent;
      
      if (isPanning) {
        e.preventDefault();
        e.stopPropagation();
        
        if (!lastPoint) return;
        
        try {
          const viewport = cornerstone.getViewport(this.element!);
          const dx = e.clientX - lastPoint.x;
          const dy = e.clientY - lastPoint.y;
          
          viewport.translation.x += dx / viewport.scale;
          viewport.translation.y += dy / viewport.scale;
          
          cornerstone.setViewport(this.element!, viewport);
          cornerstone.updateImage(this.element!);
          
          lastPoint = { x: e.clientX, y: e.clientY };
        } catch (error) {
          console.warn('Pan error:', error);
        }
      }
    };

    handlers['mouseup'] = (event: Event) => {
      const e = event as MouseEvent;
      if (!isPanning) return;
      
      isPanning = false;
      lastPoint = null;
      console.log('Pan: mouseUp, pan desactivado');
    };

    handlers['mouseleave'] = (event: Event) => {
      const e = event as MouseEvent;
      if (!isPanning) return;
      
      isPanning = false;
      lastPoint = null;
      console.log('Pan: mouseLeave, pan desactivado');
    };
    
    return handlers;
  }

  // Método para crear manejadores de medición sin registrarlos
  private createMeasurementHandlers(): { [eventType: string]: EventListener } {
    const handlers: { [eventType: string]: EventListener } = {};
    
    // Variables para el seguimiento del estado de la medición
    let isMeasuring = false;
    let startPoint: { x: number, y: number, imageX: number, imageY: number } | null = null;
    let currentPoint: { x: number, y: number, imageX: number, imageY: number } | null = null;
    let measurementLine: any = null;
    
    // Función para convertir coordenadas de pantalla a coordenadas de imagen
    const getImageCoordinates = (element: HTMLElement, clientX: number, clientY: number) => {
      const rect = element.getBoundingClientRect();
      const pageX = clientX - rect.left;
      const pageY = clientY - rect.top;
      
      try {
        const pt = cornerstone.pageToPixel(element, pageX, pageY);
        return { x: pt.x, y: pt.y };
      } catch (error) {
        console.warn('Error al convertir coordenadas:', error);
        return { x: 0, y: 0 };
      }
    };
    
    // Función para calcular la distancia entre dos puntos
    const calculateDistance = (point1: { x: number, y: number }, point2: { x: number, y: number }) => {
      const dx = point1.x - point2.x;
      const dy = point1.y - point2.y;
      return Math.sqrt(dx * dx + dy * dy);
    };
    
    // Función para dibujar la línea de medición
    const drawMeasurementLine = () => {
      if (!startPoint || !currentPoint || !this.element) return;
      
      // Obtener el contexto de dibujo
      const enabledElement = cornerstone.getEnabledElement(this.element);
      if (!enabledElement || !enabledElement.canvas) return;
      
      // Limpiar cualquier dibujo anterior
      cornerstone.updateImage(this.element);
      
      // Obtener el contexto y configurar el estilo
      const context = enabledElement.canvas.getContext('2d');
      if (!context) return;
      
      // Convertir coordenadas de imagen a coordenadas de pantalla
      const startCanvas = cornerstone.pixelToCanvas(this.element, startPoint);
      const endCanvas = cornerstone.pixelToCanvas(this.element, currentPoint);
      
      // Dibujar la línea
      context.beginPath();
      context.moveTo(startCanvas.x, startCanvas.y);
      context.lineTo(endCanvas.x, endCanvas.y);
      context.strokeStyle = 'yellow';
      context.lineWidth = 2;
      context.stroke();
      
      // Calcular la distancia en píxeles de la imagen
      const distanceInPixels = calculateDistance(
        { x: startPoint.imageX, y: startPoint.imageY },
        { x: currentPoint.imageX, y: currentPoint.imageY }
      );
      
      // Mostrar la medición
      const midPoint = {
        x: (startCanvas.x + endCanvas.x) / 2,
        y: (startCanvas.y + endCanvas.y) / 2
      };
      
      context.font = '14px Arial';
      context.fillStyle = 'yellow';
      context.textAlign = 'center';
      context.fillText(`${distanceInPixels.toFixed(2)} px`, midPoint.x, midPoint.y - 5);
      
      // Guardar la medición para referencia
      measurementLine = {
        start: startPoint,
        end: currentPoint,
        distance: distanceInPixels
      };
    };

    handlers['mousedown'] = (event: Event) => {
      const e = event as MouseEvent;
      // Solo procesar si se presiona el botón izquierdo
      if (e.button !== 0) return;
      
      // Solo activar medición si no hay otra herramienta ajustando
      if (this.isAnyToolAdjusting()) return;
      
      isMeasuring = true;
      
      // Obtener coordenadas de imagen
      const imageCoords = getImageCoordinates(this.element!, e.clientX, e.clientY);
      
      startPoint = {
        x: e.clientX,
        y: e.clientY,
        imageX: imageCoords.x,
        imageY: imageCoords.y
      };
      
      currentPoint = { ...startPoint };
      console.log('Medición: inicio en', startPoint);
    };

    handlers['mousemove'] = (event: Event) => {
      const e = event as MouseEvent;
      
      if (isMeasuring) {
        e.preventDefault();
        e.stopPropagation();
        
        if (!startPoint) return;
        
        // Obtener coordenadas de imagen
        const imageCoords = getImageCoordinates(this.element!, e.clientX, e.clientY);
        
        currentPoint = {
          x: e.clientX,
          y: e.clientY,
          imageX: imageCoords.x,
          imageY: imageCoords.y
        };
        
        // Dibujar la línea de medición
        drawMeasurementLine();
      }
    };

    handlers['mouseup'] = (event: Event) => {
      const e = event as MouseEvent;
      if (!isMeasuring) return;
      
      if (startPoint && currentPoint) {
        // Finalizar la medición
        try {
          // Guardar la medición en el estado de la herramienta
          if (measurementLine) {
            console.log('Medición completada:', measurementLine.distance.toFixed(2), 'px');
            
            // Opcional: Añadir la medición al estado de cornerstone
            try {
              const toolState = cornerstoneTools.getToolState(this.element, 'length') || {};
              if (!toolState.data) {
                toolState.data = [];
              }
              toolState.data.push(measurementLine);
              cornerstoneTools.addToolState(this.element, 'length', measurementLine);
            } catch (error) {
              console.warn('Error al guardar la medición:', error);
            }
          }
          
          // Mantener la línea visible
          drawMeasurementLine();
        } catch (error) {
          console.warn('Error al finalizar la medición:', error);
        }
      }
      
      isMeasuring = false;
    };

    handlers['mouseleave'] = (event: Event) => {
      const e = event as MouseEvent;
      if (!isMeasuring) return;
      
      isMeasuring = false;
      console.log('Medición: mouseLeave, medición finalizada');
    };
    
    return handlers;
  }

  // Método para registrar los manejadores combinados de todas las herramientas
  private registerCombinedHandlers(toolHandlers: { [key: string]: { [eventType: string]: EventListener } }): void {
    if (!this.element) return;
    
    // Limpiar los manejadores existentes
    this.removeAllCustomHandlers();
    
    // Crear manejadores combinados para cada tipo de evento
    const combinedHandlers: { [eventType: string]: EventListener } = {};
    
    // Recopilar todos los tipos de eventos de todas las herramientas
    const allEventTypes = new Set<string>();
    Object.values(toolHandlers).forEach(handlers => {
      Object.keys(handlers).forEach(eventType => allEventTypes.add(eventType));
    });
    
    // Para cada tipo de evento, crear un manejador combinado
    allEventTypes.forEach(eventType => {
      combinedHandlers[eventType] = (event: Event) => {
        // Llamar a los manejadores de cada herramienta para este tipo de evento
        Object.entries(toolHandlers).forEach(([toolName, handlers]) => {
          if (handlers[eventType]) {
            try {
              handlers[eventType](event);
            } catch (error) {
              console.warn(`Error en manejador de ${toolName} para ${eventType}:`, error);
            }
          }
        });
      };
      
      // Registrar el manejador combinado
      this.eventHandlers[eventType] = combinedHandlers[eventType];
      this.element!.addEventListener(eventType, this.eventHandlers[eventType], true);
    });
    
    // Actualizar el cursor según las herramientas activas
    this.updateCursor();
  }

  // Método para verificar si alguna herramienta está ajustando
  private isAnyToolAdjusting(): boolean {
    // Implementar lógica para verificar si alguna herramienta está en uso activo
    // Por ahora, retornamos false para permitir que cualquier herramienta se active
    return false;
  }

  // Método para actualizar el cursor según las herramientas activas
  private updateCursor(): void {
    if (!this.element) return;
    
    if (this.activeToolNames.includes('Pan')) {
      this.element.style.cursor = 'grab';
      this.element.classList.add('tool-pan-active');
      this.element.classList.remove('tool-wwwc-active', 'tool-zoom-active', 'tool-length-active');
    } else if (this.activeToolNames.includes('Zoom')) {
      this.element.style.cursor = 'zoom-in';
      this.element.classList.add('tool-zoom-active');
      this.element.classList.remove('tool-pan-active', 'tool-wwwc-active', 'tool-length-active');
    } else if (this.activeToolNames.includes('Wwwc')) {
      this.element.style.cursor = 'move';
      this.element.classList.add('tool-wwwc-active');
      this.element.classList.remove('tool-pan-active', 'tool-zoom-active', 'tool-length-active');
    } else if (this.activeToolNames.includes('Length')) {
      this.element.style.cursor = 'crosshair';
      this.element.classList.add('tool-length-active');
      this.element.classList.remove('tool-pan-active', 'tool-wwwc-active', 'tool-zoom-active');
    } else {
      this.element.style.cursor = 'default';
      this.element.classList.remove('tool-pan-active', 'tool-wwwc-active', 'tool-zoom-active', 'tool-length-active');
    }
  }

  public resetViewport(): void {
    if (!this.element) return;
    try {
      const enabledElement = cornerstone.getEnabledElement(this.element);
      if (!enabledElement) return;
      const viewport = cornerstone.getDefaultViewport(enabledElement.canvas, enabledElement.image);
      cornerstone.setViewport(this.element, viewport);
      console.log('Viewport restablecido a valores predeterminados');
    } catch (error) {
      console.error('Error al restablecer viewport:', error);
    }
  }

  public getElement(): HTMLElement | null {
    return this.element;
  }

  // Eliminar el método updateToolStates() duplicado y reemplazar todas sus referencias con updateToolState()
  public setToolActive(toolNames: string[] | string | null): void {
    if (toolNames === null) {
      this.activeToolNames = [];
    } else if (Array.isArray(toolNames)) {
      this.activeToolNames = toolNames;
    } else {
      // Si se pasa un string, convertirlo a array
      this.activeToolNames = [toolNames];
    }
    console.log('setToolActive llamado con:', this.activeToolNames);
    this.updateToolState();
  }

  public setActiveTools(toolNames: string[]): void {
    console.log('setActiveTools called with:', toolNames);
    
    // Verificar si hay herramientas incompatibles
    const hasPan = toolNames.includes('Pan');
    const hasWwwc = toolNames.includes('Wwwc');
    
    // Si ambas herramientas incompatibles están seleccionadas
    if (hasPan && hasWwwc) {
      console.log('Conflicto detectado: ambas herramientas Pan y Wwwc seleccionadas');
      
      // Determinar cuál es la nueva herramienta que se está intentando activar
      const wasPanActive = this.activeToolNames.includes('Pan');
      const wasWwwcActive = this.activeToolNames.includes('Wwwc');
      
      let message = '';
      
      if (!wasPanActive && hasPan) {
        // Si Pan es la nueva herramienta, eliminarla y mostrar mensaje
        toolNames = toolNames.filter(tool => tool !== 'Pan');
        message = "No se puede activar Mover cuando el Contraste está activado";
        console.log('Eliminando Pan de las herramientas, mostrando alerta');
      } else if (!wasWwwcActive && hasWwwc) {
        // Si Wwwc es la nueva herramienta, eliminarla y mostrar mensaje
        toolNames = toolNames.filter(tool => tool !== 'Wwwc');
        message = "No se puede activar Contraste cuando Mover está activado";
        console.log('Eliminando Wwwc de las herramientas, mostrando alerta');
      } else {
        // Si ambas estaban activas antes (caso improbable), eliminar Pan
        toolNames = toolNames.filter(tool => tool !== 'Pan');
        message = "No se pueden usar Mover y Contraste al mismo tiempo";
        console.log('Ambas herramientas estaban activas, eliminando Pan, mostrando alerta');
      }
      
      // Emitir el cambio de herramientas al componente padre
      this.toolsChanged.emit([...toolNames]);
      
      // Mostrar alerta directamente aquí, sin usar setTimeout
      try {
        Swal.fire({
          title: 'Advertencia',
          text: message,
          icon: 'warning',
          confirmButtonText: 'Entendido'
        });
        console.log('SweetAlert mostrado directamente');
      } catch (error) {
        console.error('Error al mostrar SweetAlert directamente:', error);
        // Fallback to our method with setTimeout
        this.showSweetAlert(message);
      }
    }
    
    this.activeToolNames = toolNames;
    console.log('DicomViewer: configurando herramientas activas:', toolNames.join(', ') || 'Ninguna');
    this.updateToolState();
  } 
   // Improved SweetAlert method
   private showSweetAlert(message: string): void {
     console.log('Intentando mostrar SweetAlert con mensaje:', message);
     
     // Use NgZone to ensure the alert runs in the Angular zone
     setTimeout(() => {
       try {
         // Use a more direct approach with fewer options
         Swal.fire({
           title: 'Advertencia',
           text: message,
           icon: 'warning',
           confirmButtonText: 'Entendido'
         });
         console.log('SweetAlert.fire() ejecutado');
       } catch (error) {
         console.error('Error al mostrar SweetAlert:', error);
         // Fallback alert in case SweetAlert fails
         alert(message);
       }
     }, 0);
   }

  private removeAllCustomHandlers(): void {
    if (!this.element) return;
    
    console.log('Eliminando todos los manejadores de eventos personalizados');
    
    // Lista de todos los tipos de eventos que podrían tener manejadores
    const events = ['wheel', 'mousedown', 'mousemove', 'mouseup', 'mouseleave'];
    
    // Eliminar cada manejador de eventos con ambos modos de captura
    events.forEach(eventType => {
      if (this.eventHandlers[eventType]) {
        try {
          this.element?.removeEventListener(eventType, this.eventHandlers[eventType], true);
          this.element?.removeEventListener(eventType, this.eventHandlers[eventType], false);
          console.log(`Manejador de evento ${eventType} eliminado`);
        } catch (error) {
          console.warn(`Error al eliminar manejador de evento ${eventType}:`, error);
        }
      }
    });
    
    // Limpiar el objeto de manejadores
    this.eventHandlers = {};
    
    // Restablecer el cursor
    if (this.element) {
      this.element.style.cursor = 'default';
    }
  }
  // Método para desactivar todas las herramientas de cornerstone
  private disableAllCornerstoneTools(): void {
    if (!this.element) return;
    
    try {
      console.log('Desactivando todas las herramientas de cornerstone');
      
      // Lista de todas las herramientas que podrían estar activas
      const toolNames = [
        'Wwwc', 'Pan', 'Zoom', 'Length', 'Angle', 'Probe', 
        'EllipticalRoi', 'RectangleRoi', 'FreehandRoi', 'Magnify',
        'StackScroll', 'Brush', 'Eraser', 'ArrowAnnotate'
      ];
      
      // Desactivar cada herramienta
      toolNames.forEach(toolName => {
        try {
          // Intentar desactivar la herramienta de todas las formas posibles
          try { cornerstoneTools.setToolDisabled(toolName); } catch (e) {}
          try { cornerstoneTools.setToolPassive(toolName); } catch (e) {}
          try { cornerstoneTools.setToolInactive(toolName); } catch (e) {}
          
          // Intentar eliminar la herramienta del elemento
          try {
            const toolData = cornerstoneTools.getToolForElement(this.element, toolName);
            if (toolData) {
              cornerstoneTools.removeToolForElement(this.element, toolName);
            }
          } catch (e) {}
          
          // Intentar diferentes métodos para eliminar event listeners
          try { 
            if (typeof cornerstoneTools.removeEventListeners === 'function') {
              cornerstoneTools.removeEventListeners(this.element, toolName);
            }
          } catch (e) {}
        } catch (error) {
          console.warn(`Error al desactivar la herramienta ${toolName}:`, error);
        }
      });
      
      // Limpiar cualquier estado de herramienta activa
      try {
        // Limpiar el estado de todas las herramientas
        cornerstoneTools.clearToolState(this.element);
        
        // Intentar diferentes métodos para forzar la eliminación de event handlers
        try {
          if (typeof cornerstoneTools.forceRemoveAllEventListeners === 'function') {
            cornerstoneTools.forceRemoveAllEventListeners(this.element);
          }
        } catch (e) {}
        
        // Intentar desactivar todas las herramientas de una vez
        try {
          if (typeof cornerstoneTools.setToolDisabled === 'function') {
            cornerstoneTools.setToolDisabled('*');
          }
        } catch (e) {}
        
        // Limpiar cualquier anotación o dibujo en la imagen
        cornerstone.updateImage(this.element);
      } catch (error) {
        console.warn('Error al limpiar el estado de las herramientas:', error);
      }
      
      console.log('Todas las herramientas de cornerstone desactivadas');
    } catch (error) {
      console.warn('Error al desactivar todas las herramientas:', error);
    }
  }  

    // Test method to verify SweetAlert works
    public testSweetAlert(): void {
      console.log('Testing SweetAlert');
      Swal.fire({
        title: 'Test Alert',
        text: 'This is a test alert',
        icon: 'info',
        confirmButtonText: 'OK'
      });
    }         
 
}

