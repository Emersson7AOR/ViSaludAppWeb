import { Component, ChangeDetectorRef, OnInit, ViewChild } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatCardModule } from '@angular/material/card';
import { MatTabsModule } from '@angular/material/tabs';

import * as cornerstone from 'cornerstone-core';
import * as cornerstoneTools from 'cornerstone-tools';
import * as cornerstoneWADOImageLoader from 'cornerstone-wado-image-loader';
import * as dicomParser from 'dicom-parser';
import { DicomProcessorService } from '../../../../core/services/dicom/dicom-processor.service';

// Importar los componentes
import { DicomUploaderComponent } from '../dicom-uploader/dicom-uploader.component';
import { DicomViewerComponent } from '../dicom-viewer/dicom-viewer.component';
import { DicomToolsComponent } from '../dicom-tools/dicom-tools.component';
import { DicomMetadataComponent } from '../dicom-metadata/dicom-metadata.component';

// Add this interface to handle the window with Hammer property
interface WindowWithHammer extends Window {
  Hammer?: any;
}

@Component({
  selector: 'app-modulo-visualizador',
  standalone: true,
  imports: [
    CommonModule,
    MatCardModule,
    MatTabsModule,
    DicomUploaderComponent,
    DicomViewerComponent,
    DicomToolsComponent,
    DicomMetadataComponent
  ],
  templateUrl: './modulo-visualizador.component.html',
  styleUrls: ['./modulo-visualizador.component.css']
})
export class ModuloVisualizadorComponent implements OnInit {
  @ViewChild(DicomViewerComponent) dicomViewer!: DicomViewerComponent;
  
  // Variables para el estado
  imageLoaded = false;
  metadata: any[] = [];
  fileError: string | null = null;
  currentImageId: string | null = null;
  
  // Variable para controlar herramientas activas
  activeTools = {
    zoom: false,
    pan: false,
    windowLevel: false
  };
  
  activeToolNames: string[] = []; // herramientas activas (ej. ['Zoom', 'Pan'])

  
  constructor(
    private cdr: ChangeDetectorRef,
    private dicomProcessor: DicomProcessorService
  ) {}

  ngOnInit(): void {
    if (typeof window !== 'undefined') {
      try {
        // Initialize Cornerstone Core
        console.log('🔄 Inicializando Cornerstone Core...');
        
        // Set up Cornerstone Tools
        console.log('🔄 Inicializando Cornerstone Tools...');
        cornerstoneTools.external.cornerstone = cornerstone;
        
        // Check for Hammer.js
        const windowWithHammer = window as WindowWithHammer;
        if (windowWithHammer.Hammer) {
          cornerstoneTools.external.Hammer = windowWithHammer.Hammer;
        } else {
          console.warn('Hammer.js no está disponible. Algunas interacciones táctiles podrían no funcionar.');
        }
        
        // Initialize Cornerstone Tools
        cornerstoneTools.init({
          mouseEnabled: true,
          touchEnabled: false,
          globalToolSyncEnabled: false,
          showSVGCursors: true
        });
        
        // Set up Cornerstone WADO Image Loader
        cornerstoneWADOImageLoader.external.cornerstone = cornerstone;
        cornerstoneWADOImageLoader.external.dicomParser = dicomParser;
        cornerstoneWADOImageLoader.configure({ beforeSend: () => {} });
        
        // Configure Web Workers
        if (cornerstoneWADOImageLoader.webWorkerManager) {
          cornerstoneWADOImageLoader.webWorkerManager.initialize({
            maxWebWorkers: navigator.hardwareConcurrency || 1,
            startWebWorkersOnDemand: true,
            taskConfiguration: {
              decodeTask: { usePDFJS: false }
            }
          });
        }
        
        console.log('✅ Cornerstone y Cornerstone Tools inicializados correctamente');
      } catch (error) {
        console.error('❌ Error al inicializar Cornerstone:', error);
      }
    }
  }

  processFile(file: File): void {
    this.fileError = null;
    console.log('📁 Procesando archivo:', file.name);
    const reader = new FileReader();
  
    reader.onload = () => {
      try {
        const arrayBuffer = reader.result as ArrayBuffer;
        
        // Use the service to parse the DICOM file
        const result = this.dicomProcessor.parseDicomFile(arrayBuffer);
        
        if (!result.isValid) {
          this.fileError = result.error;
          return;
        }
        
        // Extract metadata
        this.metadata = this.dicomProcessor.extractAllDicomTags(result.dataSet);
        this.metadata.sort((a, b) => a.tag.localeCompare(b.tag));
        
        console.log('📄 Metadatos extraídos:', this.metadata.length, 'tags encontrados');
  
        // Create a blob for Cornerstone to read
        const byteArray = new Uint8Array(arrayBuffer);
        const blob = new Blob([byteArray]);
        this.currentImageId = cornerstoneWADOImageLoader.wadouri.fileManager.add(blob);
        
        this.imageLoaded = true;
        this.cdr.detectChanges();
      } catch (error: any) {
        console.error('❌ Error al procesar el archivo DICOM:', error);
        this.fileError = 'Error al procesar el archivo DICOM: ' + (error.message || 'Error desconocido');
        this.cdr.detectChanges();
      }
    };
  
    reader.onerror = (error: any) => {
      console.error('❌ Error al leer el archivo:', error);
      this.fileError = 'Error al leer el archivo.';
      this.cdr.detectChanges();
    };
  
    reader.readAsArrayBuffer(file);
  }

  onZoomToggled(active: boolean): void {
    this.activeTools.zoom = active;
    console.log(active ? 'Zoom activado' : 'Zoom desactivado');
    this.updateActiveTools();
  }

  onPanToggled(active: boolean): void {
    this.activeTools.pan = active;
    console.log(active ? 'Pan activado' : 'Pan desactivado');
    this.updateActiveTools();
  }

  onWindowLevelToggled(active: boolean): void {
    this.activeTools.windowLevel = active;
    console.log(active ? 'Window Level activado' : 'Window Level desactivado');
    this.updateActiveTools();
  }

  private updateActiveTools(): void {
    const activeTools: string[] = [];
    if (this.activeTools.zoom) activeTools.push('Zoom');
    if (this.activeTools.pan) activeTools.push('Pan');
    if (this.activeTools.windowLevel) activeTools.push('Wwwc');
  
    if (this.dicomViewer) {
      this.dicomViewer.setActiveTools(activeTools);
    }
  }
  
  
 
  resetZoom(): void {
    if (this.dicomViewer) {
      this.dicomViewer.resetViewport();
    }
  }
}