import { Component, Input, OnChanges, SimpleChanges, ElementRef, ViewChild, AfterViewInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import * as cornerstone from 'cornerstone-core';
import * as cornerstoneTools from 'cornerstone-tools';
import { CornerstoneService } from '../../../../core/services/cornerstone/cornerstone.service';

@Component({
  selector: 'app-dicom-viewer',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './dicom-viewer.component.html',
  styleUrls: ['./dicom-viewer.component.css']
})
export class DicomViewerComponent implements OnChanges, AfterViewInit, OnDestroy {
  @ViewChild('dicomElement', { static: true }) dicomElement!: ElementRef;
  @Input() imageId: string | null = null;
  @Input() activeToolNames: string[] = [];

  private element: HTMLElement | null = null;
  private isToolActive = false;
  private eventHandlers: { [key: string]: EventListener } = {};

  constructor(private cs: CornerstoneService) {}

  ngAfterViewInit(): void {
    this.element = this.dicomElement.nativeElement;
    this.initializeElement();
  }
  
  ngOnChanges(changes: SimpleChanges): void {
    if (changes['imageId'] && this.imageId && this.element) {
      this.loadAndDisplayImage();
    }
    if (changes['activeToolNames'] && this.element) {
      this.updateToolStates();
    }
  }
  
  ngOnDestroy(): void {
    this.removeSafetyEventHandlers();
    if (this.element) {
      try {
        cornerstone.disable(this.element);
      } catch (error) {
        console.warn('Error disabling Cornerstone element:', error);
      }
    }
  }
  
  private initializeElement(): void {
    if (!this.element) return;
    try {
      this.element.style.width = '100%';
      this.element.style.height = '512px';
      this.element.style.backgroundColor = '#000';
      this.addSafetyEventHandlers();
      this.cs.habilitarElemento(this.element);
      if (this.imageId) {
        this.loadAndDisplayImage();
      }
    } catch (error) {
      console.error('Error initializing element:', error);
    }
  }
  
  private addSafetyEventHandlers(): void {
    if (!this.element) return;
    const safetyHandler = (event: Event) => {
      if (!this.isToolActive) {
        event.stopPropagation();
        event.preventDefault();
        return false;
      }
      return true;
    };
    this.eventHandlers['mousemove'] = safetyHandler as EventListener;
    this.eventHandlers['mousedown'] = safetyHandler as EventListener;
    this.eventHandlers['mouseup'] = safetyHandler as EventListener;
    this.element.addEventListener('mousemove', this.eventHandlers['mousemove'], true);
    this.element.addEventListener('mousedown', this.eventHandlers['mousedown'], true);
    this.element.addEventListener('mouseup', this.eventHandlers['mouseup'], true);
  }
  
  private removeSafetyEventHandlers(): void {
    if (!this.element) return;
    Object.keys(this.eventHandlers).forEach(eventType => {
      this.element?.removeEventListener(eventType, this.eventHandlers[eventType], true);
    });
    this.eventHandlers = {};
  }

  private loadAndDisplayImage(): void {
    if (!this.element || !this.imageId) return;
    this.cs.cargarYMostrarImagen(this.element, this.imageId).then(() => {
      try {
        if (!cornerstone.getEnabledElement(this.element)) {
          cornerstone.enable(this.element!);
        }
        this.cs.inicializarHerramientas(this.element!);
        cornerstone.events.addEventListener('cornerstoneimagerendered', 
          () => this.updateToolStates(),
          this.element
        );
      } catch (error) {
        console.error('Error initializing tools:', error);
      }
    }).catch(error => {
      console.error('Error loading or displaying image:', error);
    });
  }
  
  private updateToolStates(): void {
    if (!this.element) return;
  
    this.removeAllEventHandlers();
    this.isToolActive = false;
  
    // Siempre desactiva todas
    cornerstoneTools.setToolDisabled('Zoom');
    cornerstoneTools.setToolDisabled('Pan');
    cornerstoneTools.setToolDisabled('Wwwc');
  
    if (this.activeToolNames.includes('Wwwc')) {
      this.cs.activarNivelVentana(this.element);
      this.isToolActive = true;
    } else {
      this.cs.desactivarNivelVentana();
    }
  
    if (this.activeToolNames.includes('Zoom')) {
      this.implementCustomZoom();
      this.isToolActive = true;
    }
  
    if (this.activeToolNames.includes('Pan')) {
      this.implementCustomPan();
      this.isToolActive = true;
    }
  
    if (!this.isToolActive) {
      this.addSafetyEventHandlers();
    }
  
    cornerstone.updateImage(this.element);
  }
  
  
  
  private implementCustomZoom(): void {
    if (!this.element) return;
    if (this.eventHandlers['wheel']) {
      this.element.removeEventListener('wheel', this.eventHandlers['wheel'], false);
    }
    const wheelHandler = (event: WheelEvent) => {
      event.preventDefault();
      event.stopPropagation();
      try {
        const enabledElement = cornerstone.getEnabledElement(this.element!);
        if (!enabledElement || !enabledElement.image) return false;
        const viewport = cornerstone.getViewport(this.element!);
        const zoomFactor = event.deltaY < 0 ? 1.1 : 0.9;
        viewport.scale *= zoomFactor;
        cornerstone.setViewport(this.element!, viewport);
      } catch (e) {
        console.warn('Zoom error:', e);
      }
      return false;
    };
    this.eventHandlers['wheel'] = wheelHandler as unknown as EventListener;
    this.element.addEventListener('wheel', this.eventHandlers['wheel'], false);
    const mouseMoveHandler = (event: MouseEvent) => {
      event.preventDefault();
      this.element!.style.cursor = 'zoom-in';
      return false;
    };
    if (this.eventHandlers['mousemove']) {
      this.element.removeEventListener('mousemove', this.eventHandlers['mousemove'], true);
    }
    this.eventHandlers['mousemove'] = mouseMoveHandler as unknown as EventListener;
    this.element.addEventListener('mousemove', this.eventHandlers['mousemove'], true);
    console.log('Zoom personalizado activado');
  }
  
  private implementCustomPan(): void {
    if (!this.element) return;
    ['mousedown', 'mousemove', 'mouseup'].forEach(eventType => {
      if (this.eventHandlers[eventType]) {
        this.element?.removeEventListener(eventType, this.eventHandlers[eventType], true);
      }
    });
    let isPanning = false;
    let lastPoint: { x: number, y: number } | null = null;
    const mouseDownHandler = (e: MouseEvent) => {
      e.preventDefault();
      e.stopPropagation();
      isPanning = true;
      lastPoint = { x: e.clientX, y: e.clientY };
      this.element!.style.cursor = 'grabbing';
      return false;
    };
    const mouseMoveHandler = (e: MouseEvent) => {
      e.preventDefault();
      if (!isPanning) {
        this.element!.style.cursor = 'grab';
        return false;
      }
      if (isPanning && lastPoint) {
        try {
          const viewport = cornerstone.getViewport(this.element!);
          const dx = e.clientX - lastPoint.x;
          const dy = e.clientY - lastPoint.y;
          viewport.translation.x += dx / viewport.scale;
          viewport.translation.y += dy / viewport.scale;
          cornerstone.setViewport(this.element!, viewport);
          lastPoint = { x: e.clientX, y: e.clientY };
        } catch (error) {
          console.warn('Pan error:', error);
        }
      }
      return false;
    };
    const mouseUpHandler = (e: MouseEvent) => {
      e.preventDefault();
      e.stopPropagation();
      isPanning = false;
      lastPoint = null;
      this.element!.style.cursor = 'grab';
      return false;
    };
    this.eventHandlers['mousedown'] = mouseDownHandler as unknown as EventListener;
    this.eventHandlers['mousemove'] = mouseMoveHandler as unknown as EventListener;
    this.eventHandlers['mouseup'] = mouseUpHandler as unknown as EventListener;
    this.element.addEventListener('mousedown', this.eventHandlers['mousedown'], true);
    this.element.addEventListener('mousemove', this.eventHandlers['mousemove'], true);
    this.element.addEventListener('mouseup', this.eventHandlers['mouseup'], true);
    const mouseLeaveHandler = (e: MouseEvent) => {
      isPanning = false;
      lastPoint = null;
      this.element!.style.cursor = 'grab';
      return false;
    };
    this.eventHandlers['mouseleave'] = mouseLeaveHandler as unknown as EventListener;
    this.element.addEventListener('mouseleave', this.eventHandlers['mouseleave'], true);
    console.log('Pan personalizado activado');
  }
  
  public resetViewport(): void {
    if (!this.element) return;
    try {
      const enabledElement = cornerstone.getEnabledElement(this.element);
      if (!enabledElement) return;
      const viewport = cornerstone.getDefaultViewport(enabledElement.canvas, enabledElement.image);
      cornerstone.setViewport(this.element, viewport);
      console.log('Viewport restablecido a valores predeterminados');
    } catch (error) {
      console.error('Error al restablecer viewport:', error);
    }
  }
  
  public getElement(): HTMLElement | null {
    return this.element;
  }
  
  public setActiveTools(toolNames: string[]): void {
    this.activeToolNames = toolNames;
    this.updateToolStates();
  }
  private removeAllEventHandlers(): void {
    if (!this.element) return;
  
    const eventos = ['wheel', 'mousedown', 'mousemove', 'mouseup', 'mouseleave'];
    for (const ev of eventos) {
      if (this.eventHandlers[ev]) {
        this.element.removeEventListener(ev, this.eventHandlers[ev], true);
      }
    }
    this.eventHandlers = {};
  }
  
  
}
