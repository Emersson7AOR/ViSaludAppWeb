import { Component, EventEmitter, Input, Output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatCardModule } from '@angular/material/card';
import { MatTooltipModule } from '@angular/material/tooltip';

@Component({
  selector: 'app-dicom-tools',
  standalone: true,
  imports: [CommonModule, MatButtonModule, MatIconModule, MatCardModule, MatTooltipModule],
  templateUrl: './dicom-tools.component.html',
  styleUrls: ['./dicom-tools.component.css']
})
export class DicomToolsComponent {
  @Input() activeTools: { zoom: boolean, pan: boolean, windowLevel: boolean } = {
    zoom: false,
    pan: false,
    windowLevel: false
  };

  @Output() zoomToggled = new EventEmitter<boolean>();
  @Output() panToggled = new EventEmitter<boolean>();
  @Output() windowLevelToggled = new EventEmitter<boolean>();
  @Output() resetRequested = new EventEmitter<void>();

  toggleZoom(): void {
    this.zoomToggled.emit(!this.activeTools.zoom);
  }

  togglePan(): void {
    this.panToggled.emit(!this.activeTools.pan);
  }

  toggleWindowLevel(): void {
    this.windowLevelToggled.emit(!this.activeTools.windowLevel);
  }

  resetView(): void {
    this.resetRequested.emit();
  }
}
